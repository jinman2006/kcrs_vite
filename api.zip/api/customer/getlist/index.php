<?php
require_once "../../inc/db.php";
require_once "../../inc/class_token.php";

$authorization = explode(' ',$_SERVER['HTTP_AUTHORIZATION']);
$get_token = $authorization[1];
$checkres = $token->CheckToken($get_token);
$checkres['username']='super-admin';
// if($checkres['code'] === '200'){
	
	$conditions = ['creator = ?'];
	$params = [$checkres['username']];
	$fields = ['id','name','aliasname','contact','position','area','phone','models','addr','status','create_time'];
	$rs = $db->select('customerlist',$conditions,$params,$fields,'');

$data['success']=true;
$data['message']='success';
$data['data']=$rs;
$data['code']=200;

// }else{
// 	echo 'error';
// }
echo json_encode($data,JSON_UNESCAPED_UNICODE);

?>