<?php
require_once "../../inc/db.php";
require_once "../../inc/class_token.php";

$authorization = explode(' ',$_SERVER['HTTP_AUTHORIZATION']);
$get_token = $authorization[1];
$checkres = $token->CheckToken($get_token);

if($checkres['code'] === '200'){
    if (empty($_POST) && false !== strpos($_SERVER['HTTP_CONTENT_TYPE'], 'application/json')) {
        $content = file_get_contents('php://input');
        $post    = (array)json_decode($content, true);
    } else {
        $post = $_POST;
    }

    $id = $post['id'];

    $conditions = ['id = ?'];
    $params = [$id];

    $selectedData = $db->selectOne('customerlist',$conditions,$params);

    if($selectedData){
	     $data['success']=true;
	     $data['data'] = $selectedData;
	     $data['message']= '查询成功';
	     $data['code']= 200;    	
    }else{
   		$data['success']=false;
     	$data['message']='查询失败';
     	$data['code']= 400;
    }



}else{
        $data['success']=false;
        $data['message']=$checkres['message'];
        $data['code']= 400;      
}


// $checkres['username']='super-admin';
// // if($checkres['code'] === '200'){
	
// 	$conditions = ['creator = ?'];
// 	$params = [$checkres['username']];
// 	$fields = ['id','name','contact','position','area','phone','models','addr','status','create_time'];
// 	$rs = $db->select('customerlist',$conditions,$params,$fields,'');

// $data['success']=true;
// $data['message']='success';
// $data['data']=$rs;
// $data['code']=200;

// // }else{
// // 	echo 'error';
// // }
echo json_encode($data,JSON_UNESCAPED_UNICODE);

?>