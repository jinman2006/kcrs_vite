<?php
require_once "../../inc/db.php";
require_once "../../inc/class_token.php";

$authorization = explode(' ',$_SERVER['HTTP_AUTHORIZATION']);
$get_token = $authorization[1];
$checkres = $token->CheckToken($get_token);


if($checkres['code'] === '200'){


    if (empty($_POST) && false !== strpos($_SERVER['HTTP_CONTENT_TYPE'], 'application/json')) {
        $content = file_get_contents('php://input');
        $post    = (array)json_decode($content, true);
    } else {
        $post = $_POST;
    }

    $create_time = date('Y-m-d H:i:s');
    $creator = $checkres['username'];


    $post['area'] = implode('/', $post['area']);
    $post['status'] = 'pending';
    $post['create_time'] = $create_time;
    $post['creator'] = $creator;

    $insertData = $db->insert('customerlist',$post,true);

    if($db->affected_rows()>0){
        $data['success']=true;
        $data['data']=$insertData;
        $data['message']='操作成功';
        $data['code']= 200;  

    }else{
        $data['success']=false;
        $data['message']='操作失败'.$insertData;
        $data['code']= 400;    
    }

    $db->closestmt();
}else{
        $data['success']=false;
        $data['message']=$checkres['message'];
        $data['code']= 400;      
}


// echo json_encode($post);



echo json_encode($data, JSON_UNESCAPED_UNICODE);


?>