<?php
require_once "../../inc/db.php";
require_once "../../inc/class_token.php";

// 操作表名
$dbtable='users';


if (empty($_POST) && false !== strpos($_SERVER['HTTP_CONTENT_TYPE'], 'application/json')) {
    $content = file_get_contents('php://input');
    $post    = (array)json_decode($content, true);
} else {
    $post = $_POST;
}

$username=$post['username'];
$password=$post['password'];



$conditions = ['account = ?'];
$params = [$username];
$fields = ['id','account','password'];


$rs = $db->selectOne('users',$conditions,$params,$fields);

if($rs){
    if($rs['password'] === $password){
        $data['success'] = true;
        $data['code'] = 200;
        $data['message'] = '登录成功';
        $data['data']['token'] = $token->CreateToken($rs['account']);        
    }else{
        $data['success'] = false;
        $data['code'] = 400;
        $data['message'] = '密码错误';
    }

}else{
    $data['success'] = false;
    $data['code'] = 400;
    $data['message'] = '帐号不存在';
}

echo json_encode($data,JSON_UNESCAPED_UNICODE);

$db->disconnect();

?>