<?php
$a=['*'];
$b = implode(',', $a);

echo $b;
?>