
<?php
//加密
 function encrypt($data)
{
 
    if ($data== null || empty($data)) {
        return $data;
    }
    $secret_key = "C38CE0F80FAF0E86";
    $iv = "King3351King3351";
    $result= base64_encode(openssl_encrypt( $data, "aes-256-cbc", $secret_key, OPENSSL_RAW_DATA, $iv));
 
    return $result;
    
}
 
//解密
 function decrypt($data)
{
    if ($data== null || empty($data)) {
        return $data;
    }
    $secret_key = "C38CE0F80FAF0E86";
    $iv = "King3351King3351";
    $result= openssl_decrypt(base64_decode($data), "aes-256-cbc", $secret_key, OPENSSL_RAW_DATA, $iv);
 
    return $result;
   
}
// super-admin.1728606022.1728609622.eedab1e065e9e7d5d27bdd0d60c1849c
echo encrypt('super-admin.1728606022.1728609622');
echo '<br />';

echo decrypt('IXkQozC83CRZY/jqmQs5RR0oLLcfznxVm8nM3YkLscW8abZBh4zUCpotx7GiTZhl');
?>