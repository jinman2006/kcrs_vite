<?php
// require_once "../inc/db.php";

// // 实例化
// $db = new DB_API($config);

// $insertData = array(
//         'account' => '13957338174',
//         'password' => 1,
//  );
$_POST['test']=1111;
echo json_encode($_POST);
 // $insertSQL = $db->add('users', $insertData);

 //    // 结果
 //    if ($insertSQL) {
        
 //        // 成功
 //        echo '插入成功，ID是：' . $insertSQL;
 //    } else {
        
 //        // 失败
 //        echo '插入失败，原因：' . $db->errorMsg();
 //    }
?>