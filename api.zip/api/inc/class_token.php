<?php
class TOKEN {
    const SIGNATURE = 'C38CE0F80FAF0E86';
    //生成token
    public function CreateToken($userid) {
        $time = time();
        $end_time = time() + 3600;
        $info = $userid . '.' . $time . '.' . $end_time; //设置token过期时间为一天
        //根据以上信息信息生成签名（密钥为 SIGNATURE 自定义全局常量)
        $signature = hash_hmac('md5', $info, self::SIGNATURE);
        //将info进行简单加密，最后将这两部分拼接起来，得到最终的Token字符串
        return $token = $this->encrypt($info) . '.' . $signature.'.'.$end_time;
    }
     
    //检查token，加密info
    public function CheckToken($token){
        if (!isset($token) || empty($token)) {
            $data['code'] = '400';
            $data['message'] = '非法请求';
            return $data;
        }
        // 对比token
        $split_token = explode('.',$token);
        if(!empty($split_token[0]) && !empty($split_token[1])){
            $info = $this->decrypt($split_token[0]);//解密得到真实的info
            $split_info = explode('.',$info);
            $true_signature = hash_hmac('md5', $info, self::SIGNATURE); //正确的签名
            if (time() > $split_info[2]) {
                $data['code'] = '401';
                $data['message'] = 'Token已过期,请重新登录';
                return $data;
            }
            if ($true_signature == $split_token[1]) {
                $data['code'] = '200';
                $data['message'] = 'Token合法';
                $data['username'] = $split_info[0];
                return $data;
            } else {
                $data['code'] = '400';
                $data['message'] = 'Token不合法';
                return $data;
            }            
        }else{
            $data['code'] = '400';
            $data['message'] = 'Token不合法';
            return $data;            
        }
    }

    // 未加密info版
    public function CheckToken2($token) {
        if (!isset($token) || empty($token)) {
            $data['code'] = '400';
            $data['message'] = '非法请求';
            return $data;
        }
        //对比token
        $explode = explode('.', $token); //以.分割token为数组
        if (!empty($explode[0]) && !empty($explode[1]) && !empty($explode[2]) && !empty($explode[3])) {
            $info = $explode[0] . '.' . $explode[1] . '.' . $explode[2]; //信息部分
            $true_signature = hash_hmac('md5', $info, self::SIGNATURE); //正确的签名
            if (time() > $explode[2]) {
                $data['code'] = '401';
                $data['message'] = 'Token已过期,请重新登录';
                return $data;
            }
            if ($true_signature == $explode[3]) {
                $data['code'] = '200';
                $data['message'] = 'Token合法';
                return $data;
            } else {
                $data['code'] = '400';
                $data['message'] = 'Token不合法';
                return $data;
            }
        } else {
            $data['code'] = '400';
            $data['message'] = 'Token不合法';
            return $data;
        }
    }  


    //加密
    public function encrypt($data)
    {
     
        if ($data== null || empty($data)) {
            return $data;
        }
        $secret_key = "C38CE0F80FAF0E86";
        $iv = "King3351King3351";
        $result= base64_encode(openssl_encrypt( $data, "aes-256-cbc", $secret_key, OPENSSL_RAW_DATA, $iv));
     
        return $result;
        
    }
     
    //解密
    public function decrypt($data)
    {
        if ($data== null || empty($data)) {
            return $data;
        }
        $secret_key = "C38CE0F80FAF0E86";
        $iv = "King3351King3351";
        $result= openssl_decrypt(base64_decode($data), "aes-256-cbc", $secret_key, OPENSSL_RAW_DATA, $iv);
     
        return $result;
       
    }

}

// 实例化
$token = new TOKEN();
?>