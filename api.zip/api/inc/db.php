<?php
    
    // 配置文件
    $config = array(
        'db_host' => 'localhost',
        'db_port' => 3306,
        'db_name' => 'kcrs',
        'db_user' => 'root',
        'db_pass' => 'root'
    );

    // 引入操作类
    include 'class_mysqli.php';    

    // 实例化 
    $db = new Database($config['db_host'], $config['db_user'], $config['db_pass'], $config['db_name']);
?>