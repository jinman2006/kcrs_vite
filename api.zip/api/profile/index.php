<?php
require_once "../inc/db.php";
require_once "../inc/class_token.php";

$authorization = explode(' ',$_SERVER['HTTP_AUTHORIZATION']);
$get_token = $authorization[1];
$checkres = $token->CheckToken($get_token);



if($checkres['code'] === '200') {
	$arr_token = explode('.',$get_token);
	$username = $checkres['username'];

	$conditions = ['account = ?'];
	$params = [$username];
	$rs = $db->selectOne('userinfo',$conditions,$params);
	if($rs){
		
	}
	$data['data'] = $rs;
	$data['success'] = true;
	$data['message'] = '获取资料成功';
}else{
	http_response_code($checkres['code']);
	$data = $checkres;
	$data['data']=[];
	$data['success'] = false;
}

echo json_encode($data,JSON_UNESCAPED_UNICODE);

// if (empty($_POST) && false !== strpos($_SERVER['HTTP_CONTENT_TYPE'], 'application/json')) {
//     $content = file_get_contents('php://input');
//     $post    = (array)json_decode($content, true);
// } else {
//     $post = $_POST;
// }

// $a=[1,2,3,4];
// echo json_encode($a);
?>